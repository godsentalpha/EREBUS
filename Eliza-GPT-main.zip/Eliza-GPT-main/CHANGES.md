# Eliza-GPT Change Log

**Release 0.2.0** - 2023-12-28

- Use microdot's SSE extension ([commit](https://github.com/miguelgrinberg/eliza-gpt/commit/0a1f3e087e97284c0c4dcd0ea766c7fdd5dd6a63))
- Documentation for the example applications ([commit](https://github.com/miguelgrinberg/eliza-gpt/commit/a559d14c2cf4bfbc60780186ccb004afd77a799b))

**Release 0.1.1** - 2023-12-24

- Fix issues with Python packaging ([commit](https://github.com/miguelgrinberg/eliza-gpt/commit/b6d885fdefe644d6863f2cc84a2b769a46e040b7))

**Release 0.1.0** - 2023-12-24

- Initial release
